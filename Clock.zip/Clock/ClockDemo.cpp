#include "Clock.h"
#include <conio.h>

void menu()// print out for the question
{
	cout << "***********************************" << endl;
	cout << "1 - Add One Hour"<< endl;
	cout << "2 - Add One Minute" << endl;
	cout << "3 - Add One Second" << endl;
	cout << "4 - Exit" << endl;
	cout << "***********************************" << endl;
}

int main()//print out of the time in both 12 and 24 hours
{
	Clock clock12(false), clock24(true);
	int choice;
	bool exit = false;
	while (!exit)
	{
		cout << "***********************************" << endl;//the line above the display
		cout << "*" << setw(12);
		clock12.displayTime(cout);// 12 hour display
		cout << " * ";
		cout << "*" << setw(12);
		clock24.displayTime(cout);// 24 hour display
		cout << " *" << endl;
		cout << "***********************************" << endl;// the lower level line display
		cout << endl;
		menu();
		cin >> choice;
		switch (choice)
		{
		case 1://for hours
			clock12.addHours(1);
			clock24.addHours(1);
			break;
		case 2://for minutes
			clock12.addMinutes(1);
			clock24.addMinutes(1);
			break;
		case 3://for seconds
			clock12.addSeconds(1);
			clock24.addSeconds(1);
			break;
		case 4:// to exit the program
			exit = true;
		default:
			break;
		}
		system("CLS");
	}
}