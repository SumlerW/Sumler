#include <iostream>

// Wes Sumler
// 03.20.2023
using namespace  std;

#include "Clock.h"

Clock::Clock(bool Format_24) {
	time_t seconds = time(0);
	localTime = localtime(&seconds);
	set_hours = 0;
	set_secs = 0;
	set_mins = 0;
	this->format_24 = format_24;
}

void Clock::addHours(int hours) {// to add hours
	set_hours += hours;
}
void Clock::addMinutes(int mins) {// to add mins
	set_mins += mins;
}
void Clock::addSeconds(int secs) {// to add secs
	set_secs += secs;
}
void Clock::resetClock() {//to start over
	set_hours = 0;
	set_secs = 0;
	set_mins = 0;
}
void Clock::displayTime(ostream& out)
{
	int seconds = 0, minutes = 0, hours = 0;
	seconds = localTime->tm_sec + set_secs;
	minutes += (seconds / 60);//the amount of mins you can have
	seconds = seconds % 60;//the amount of secs you can have

	minutes += localTime->tm_min + set_mins;
	hours += minutes / 60;
	minutes = minutes % 60;

	hours = (hours + localTime->tm_hour + set_hours) % 24;//the amount of hours you can have

	string timestr = "";// (hours:mins:sec )
	out << setw(2) << setfill('0') << (format_24 ? hours : (hours % 12)) << ":";
	out << setw(2) << setfill('0') << minutes << ":";
	out << setw(2) << setfill('0') << seconds << " ";
	if (!format_24) {
		if (hours > 12)// am or pm
		{
			out << "PM";
		}
		else
		{
			out << "AM";
		}
	}
}