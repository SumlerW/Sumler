#ifndef CLOCK_H_
#define CLOCK_H_
#include<iostream>
#include<ctime>
#include<cstdlib>
#include<iomanip>

using namespace std;
class Clock //class for the clock
{
private://plug in for the times
	struct tm* localTime;
	int set_hours;
	int set_mins;
	int set_secs;
	bool format_24;
public:
	Clock(bool format_24);
	void addHours(int hours);
	void addMinutes(int mins);
	void addSeconds(int secs);
	void resetClock();
	void displayTime(ostream& out);
};
#endif



